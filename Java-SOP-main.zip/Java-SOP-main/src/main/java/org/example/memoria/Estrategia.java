package org.example.memoria;

public enum Estrategia {
    FIRST_FIT,
    BEST_FIT,
    WORST_FIT
}