package org.example.sistema;

public enum TipoDeChamada {
    OPEN_PROCESS,
    READ_PROCESS,
    CLOSE_PROCESS,
    WRITE_PROCESS
}