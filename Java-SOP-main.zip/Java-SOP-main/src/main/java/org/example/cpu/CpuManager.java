package org.example.cpu;

public class CpuManager {
}
